import{p as t}from"./proxy.CdfeBWYI.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
