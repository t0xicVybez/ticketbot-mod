import{e}from"./index.BFqC5wTN.js";e();
