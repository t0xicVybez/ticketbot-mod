import{a as t}from"../chunks/entry.DD3pBHu9.js";export{t as start};
