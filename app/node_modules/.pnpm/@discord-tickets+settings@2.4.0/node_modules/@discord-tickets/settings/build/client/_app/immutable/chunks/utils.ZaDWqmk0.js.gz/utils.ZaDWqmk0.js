import{n as b,A as e}from"./runtime.D2_qJMqH.js";function o(n,u,r){if(n==null)return u(void 0),b;const s=e(()=>n.subscribe(u,r));return s.unsubscribe?()=>s.unsubscribe():s}export{o as s};
